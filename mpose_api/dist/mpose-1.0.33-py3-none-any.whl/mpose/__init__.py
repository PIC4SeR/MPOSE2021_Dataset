CONFIG_FILE = './config.yaml'

from .mpose import MPOSE

